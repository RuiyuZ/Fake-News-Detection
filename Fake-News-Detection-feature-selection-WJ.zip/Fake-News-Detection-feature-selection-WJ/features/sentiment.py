def extract():
    pass
